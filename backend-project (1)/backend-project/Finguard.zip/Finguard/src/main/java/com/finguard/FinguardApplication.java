package com.finguard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinguardApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinguardApplication.class, args);
	}

}
